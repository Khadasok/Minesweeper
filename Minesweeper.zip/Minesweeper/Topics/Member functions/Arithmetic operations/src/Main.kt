class ArithmeticOperations(val x: Int, val y: Int) {
    fun addition() = x + y
    fun subtraction() = x - y
    fun multiplication() = x * y
    fun division() = x / y
}