class Patient(val name: String) {
    fun say() = println("Hello, my name is $name, I need a doctor.")
}