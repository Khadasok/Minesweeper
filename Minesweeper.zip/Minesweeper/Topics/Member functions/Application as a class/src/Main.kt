class Application(val name: String) {
    fun run(a: String, b: String, c: String) {
        println(name)
        println(a)
        println(b)
        println(c)
    }
}
