const val TEN = 10
fun Int.lastDigit(): Int = this % TEN
