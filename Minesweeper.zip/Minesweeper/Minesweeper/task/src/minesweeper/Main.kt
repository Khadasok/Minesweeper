package minesweeper
import kotlin.system.exitProcess


const val H = "—"
const val V = "│"
const val DIM = 9
const val MARK = '*'
const val MINE = 'X'
const val FREE = '/'
const val HIDE = '.'

class Field {
    var first = true
    var boom = false
    // first to print, second to hide
    val cells = MutableList(DIM) { MutableList(DIM) { HIDE to '0' } }
    var mines = 0
    var x = 0
    var y = 0
    var correct = 0
    var extra = 0
}

fun main() {
    val field = Field()
    println("How many mines do you want on the field?")
    field.mines = readln().toInt()
    setMines(field, field.mines)
    game(field)
}

fun game(field: Field) {
    printField(field)
    println("Set/unset mine marks or claim a cell as free: ")
    val (a, b, com)= readln().split(' ')
    field.x = b.toInt() - 1
    field.y = a.toInt() - 1
    if (field.cells[field.x][field.y].first.isDigit()) {
        println("There is a number here!")
        game(field)
    }
    if (field.first && com == "free") {
        if (field.cells[field.x][field.y].second == MINE) {
            field.cells[field.x][field.y] = FREE to '0'
            setMines(field, 1)
            rearrange(field)
        }
        field.cells[field.x][field.y] = FREE to field.cells[field.x][field.y].second
        field.first = false
        explore(field)
        game(field)
    }
    if (com == "free") explore(field) else mark(field)
    game(field)
}

fun printField(field: Field) {
    val frame = "$H$V${H.repeat(DIM)}$V"
    print(" $V")
    for (i in 1 .. DIM) {
        print(i)
    }
    println(V)
    println(frame)
    for (i in field.cells.indices) {
        print("${i + 1}$V")
        field.cells[i].forEach {
            print(if (field.boom && it.second == MINE || it.first == FREE && it.second.isDigit()) it.second else it.first)
        }
        println(V)
    }
    println(frame)
    if (field.boom) {
        println("You stepped on a mine and failed!")
        exitProcess(0)
    }
    if (field.correct == field.mines && field.extra == 0 && field.mines > 0) {
        println("Congratulations! You found all the mines!")
        exitProcess(0)
    }
}

fun setMines(field: Field, mines: Int) {
    var count = 0
    while (count < mines) {
        val a = (0..8).random()
        val b = (0..8).random()
        val cell = field.cells[a][b]
        if (cell.second != MINE) {
            ++count
            field.cells[a][b] = field.cells[a][b].first to MINE
            for (x in setRange(a)) {
                for (y in setRange(b)) {
                    getHints(field, x, y)
                }
            }
        }
    }
}

fun rearrange(field: Field) {
    val c = field.cells[field.x][field.y].second
    for (i in setRange(field.x)) {
        for (j in setRange(field.y)) {
            val a = field.cells[i][j].first
            val b = field.cells[i][j].second
            when {
                b.isDigit() -> field.cells[i][j] = b - 1 to b - 1
                b == MINE -> field.cells[field.x][field.y] = c + 1 to c + 1
                else -> b to b
            }
        }
    }
}

fun getHints(field: Field, a: Int, b: Int) {
    field.cells[a][b] = when {
        field.cells[a][b].second == MINE -> field.cells[a][b].first to MINE
        field.cells[a][b].first == FREE -> '1' to '1'
        else -> HIDE to field.cells[a][b].second + 1
    }
}

fun setRange(a: Int): IntRange {
    return when(a) {
        0 -> 0..1
        8 -> 7..8
        else -> a - 1..a + 1
    }
}

fun explore(field: Field) {
    when(field.cells[field.x][field.y].second) {
        MINE -> {
            field.boom = true
        }
        else -> {
            fillUp(field)
        }
    }
}

fun mark(field: Field) {
    val a = field.cells[field.x][field.y].first
    val b = field.cells[field.x][field.y].second
    when {
        a == HIDE && b == MINE -> {
            field.cells[field.x][field.y] = MARK to MINE
            ++field.correct
        }
        a == MARK && b == MINE -> {
            field.cells[field.x][field.y] = HIDE to MINE
            --field.correct
        }
        a == MARK -> {
            field.cells[field.x][field.y] = HIDE to b
            --field.extra
        }
        else -> {
            field.cells[field.x][field.y] = MARK to b
            ++field.extra
        }
    }
}

fun fillUp(field: Field) {
    val a = field.x
    val b = field.y
    val toCheck = mutableListOf(a to b)
    val checked = mutableListOf(a to b)
    while (toCheck.isNotEmpty()) {
        val current = toCheck.first()
        for (i in setRange(current.first)) {
            for (j in setRange(current.second)) {
                val fill = field.cells[i][j]
                if (fill.first == MARK) --field.extra
                when(fill.second) {
                    MINE -> if (fill.first == MARK)field.cells[i][j] = MARK to MINE else HIDE to MINE
                    '0' -> {
                        if (!checked.contains(i to j)) {
                            checked.add(i to j)
                            toCheck.add(i to j)
                        }
                        field.cells[i][j] = FREE to FREE
                    }
                    else -> {
                        if (!checked.contains(i to j)) {
                            checked.add(i to j)
                        }
                        field.cells[i][j] = fill.second to fill.second
                    }
                }
            }
        }
        toCheck.removeAt(0)
    }
}